<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	class Cats extends CI_Controller{

		public function update(){

			$cat_id = $this->input->post('cat-id');

			// Create array for product table + insert
			$cat_array = array('name' => $this->input->post('cat_name'),
							   'sample_number' => $this->input->post('cat_sample_no'),
							   'description' => $this->input->post('desc'),
							   'final_price' => $this->input->post('cat_override'),
								 'category_id' => $this->input->post('category_id')
							  );
			$this->load->model('catalogue_model');
			$result_cat_update = $this->catalogue_model->update_cat($cat_id, $cat_array);

			// Create array for product_attribute table + insert
			$cat_attr_array = array(
				'gross_weight_price' => $this->input->post('gross_weight_price'),
				'gross_weight_converter' => $this->input->post('gross_weight_converter'),
				'gross_weight_monolith' => $this->input->post('gross_weight_monolith'),
				'monolight_dry_weight_moisture' => $this->input->post('monolight_dry_weight_moisture'),
				'monolight_dry_weight_metal' => $this->input->post('monolight_dry_weight_metal'),
				'monolight_dry_weight_net' => $this->input->post('monolight_dry_weight_net'),
				'analysis_accepted_pd' => $this->input->post('analysis_accepted_pd'),
				'analysis_accepted_pt' => $this->input->post('analysis_accepted_pt'),
				'analysis_accepted_rh' => $this->input->post('analysis_accepted_rh'),
				'metal_content_pd' => $this->input->post('metal_content_pd'),
				'metal_content_pt' => $this->input->post('metal_content_pt'),
				'metal_content_rh' => $this->input->post('metal_content_rh'),
				'value_returned_pd' => $this->input->post('value_returned_pd'),
				'value_returned_pt' => $this->input->post('value_returned_pt'),
				'value_returned_rh' => $this->input->post('value_returned_rh'),
				'value_returned_total' => $this->input->post('value_returned_total'),
				'refining_charges_pd' => $this->input->post('refining_charges_pd'),
				'refining_charges_pt' => $this->input->post('refining_charges_pt'),
				'refining_charges_rh' => $this->input->post('refining_charges_rh'),
				'sales_charges_pd' => $this->input->post('sales_charges_pd'),
				'sales_charges_pt' => $this->input->post('sales_charges_pt'),
				'sales_charges_rh' => $this->input->post('sales_charges_rh'),
				'metal_returned_pd' => $this->input->post('metal_returned_pd'),
				'metal_returned_pt' => $this->input->post('metal_returned_pt'),
				'metal_returned_rh' => $this->input->post('metal_returned_rh'),
				'process_charges_tc' => $this->input->post('process_charges_tc'),
				'process_charges_decan' => $this->input->post('process_charges_decan'),
				'process_charges_comm' => $this->input->post('process_charges_comm'),
				'process_charges_lot' => $this->input->post('process_charges_lot'),
				'converter' => $this->input->post('converter')
			);

			$result_array_cat_update = $this->catalogue_model->update_cat_attr($cat_id, $cat_attr_array);

			$this->load->model('benchmarks_model');
			$this->benchmarks_model->update_cat_price($cat_id);


			//handle main image upload - mainImg

					$config['upload_path'] = './temp';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';

					$this->load->library('upload', $config);

					$errors = false;



						if ($_FILES['mainImg']['tmp_name'] != "")
						{
							error_log($_FILES['mainImg']['tmp_name']);
							// If error occurs
						if (! $this->upload->do_upload('mainImg')){
							$this->session->set_flashdata('notice', $this->upload->display_errors());
							$errors = true;
							redirect(site_url() . '/pages/view/edit_cat/' . $cat_id);
							}

						else{

							$mainImage = $this->upload->data();
							//$this->session->set_flashdata('notice', $this->upload->data('file_name'));
							// Resize the image
							// Delete the original

							}



						if($errors)
						// There was errors, we have to delete the uploaded files
						{

							@unlink($mainImage['full_path']);

						}

						else{

							//error_log(var_export($files, true));
							$this->load->library('image_lib');

							//Create folder
							//$dir_path = './inv_images/' . $invoice_id;

							// Check if directory exists
							//if(!is_dir($dir_path)){
							//	mkdir($dir_path, 0777);
							//}


							// Set up Image Manipulation
								$config_m['image_library'] = 'gd2';
								$config_m['maintain_ratio'] = TRUE;
								$config_m['width'] = 600;
								$config_m['source_image'] = $mainImage['full_path'];

								$this->image_lib->clear();
								$this->image_lib->initialize($config_m);
								$this->image_lib->resize();

								$image_filename = $mainImage['file_name'];
								$new_path = './' . 'cat_img/resized_cat_images_600/' . $image_filename;
								rename($mainImage['full_path'], $new_path);

								// Save thumbnail
								// Copy Image
								$new_path_300 = './cat_img/resized_cat_images_300/' . $image_filename;
								copy($new_path, $new_path_300);

								$this->image_lib->clear();
								$config_m['image_library'] = 'gd2';
								$config_m['maintain_ratio'] = TRUE;
								$config_m['width'] = 300;
								$config_m['source_image'] = $new_path_300;
								$this->image_lib->initialize($config_m);
								$this->image_lib->resize();

								//Save to database
								$img_array = array( 'image' => $image_filename );
								$this->load->model('catalogue_model');
								$result_image = $this->catalogue_model->update_image($cat_id, $img_array);

						}
						}

			// End Image Processing

			if ($result_cat_update && $result_array_cat_update ){
				$this->session->set_flashdata('notice', 'Cat Updated Successfully');
			}
			else{
				$this->session->set_flashdata('notice', 'Error updating Cat');
			}
			redirect(site_url() . '/pages/view/edit_cat/' . $cat_id);
		}



		public function save(){

			// Create array for product table + insert
			$cat_array = array('name' => $this->input->post('cat_name'),
							   'sample_number' => $this->input->post('cat_sample_no'),
							   'description' => $this->input->post('desc'),
							   'final_price' => $this->input->post('cat_override'),
								 'category_id' => $this->input->post('category_id')
							  );
			$this->load->model('catalogue_model');
			$cat_id = $this->catalogue_model->save_cat($cat_array);

			// Create array for product_attribute table + insert
			$cat_attr_array = array(
				'id' => $cat_id,
				'product_id' => $cat_id,
				'gross_weight_price' => $this->input->post('gross_weight_price'),
				'gross_weight_converter' => $this->input->post('gross_weight_converter'),
				'gross_weight_monolith' => $this->input->post('gross_weight_monolith'),
				'monolight_dry_weight_moisture' => $this->input->post('monolight_dry_weight_moisture'),
				'monolight_dry_weight_metal' => $this->input->post('monolight_dry_weight_metal'),
				'monolight_dry_weight_net' => $this->input->post('monolight_dry_weight_net'),
				'analysis_accepted_pd' => $this->input->post('analysis_accepted_pd'),
				'analysis_accepted_pt' => $this->input->post('analysis_accepted_pt'),
				'analysis_accepted_rh' => $this->input->post('analysis_accepted_rh'),
				'metal_content_pd' => $this->input->post('metal_content_pd'),
				'metal_content_pt' => $this->input->post('metal_content_pt'),
				'metal_content_rh' => $this->input->post('metal_content_rh'),
				'value_returned_pd' => $this->input->post('value_returned_pd'),
				'value_returned_pt' => $this->input->post('value_returned_pt'),
				'value_returned_rh' => $this->input->post('value_returned_rh'),
				'value_returned_total' => $this->input->post('value_returned_total'),
				'refining_charges_pd' => $this->input->post('refining_charges_pd'),
				'refining_charges_pt' => $this->input->post('refining_charges_pt'),
				'refining_charges_rh' => $this->input->post('refining_charges_rh'),
				'sales_charges_pd' => $this->input->post('sales_charges_pd'),
				'sales_charges_pt' => $this->input->post('sales_charges_pt'),
				'sales_charges_rh' => $this->input->post('sales_charges_rh'),
				'metal_returned_pd' => $this->input->post('metal_returned_pd'),
				'metal_returned_pt' => $this->input->post('metal_returned_pt'),
				'metal_returned_rh' => $this->input->post('metal_returned_rh'),
				'process_charges_tc' => $this->input->post('process_charges_tc'),
				'process_charges_decan' => $this->input->post('process_charges_decan'),
				'process_charges_comm' => $this->input->post('process_charges_comm'),
				'process_charges_lot' => $this->input->post('process_charges_lot'),
				'converter' => $this->input->post('converter')
			);

			$result_array_cat_save = $this->catalogue_model->save_cat_attr($cat_attr_array);

			$this->load->model('benchmarks_model');
			$this->benchmarks_model->update_cat_price($result_array_cat_save);

			//handle main image upload - mainImg

					$config['upload_path'] = './temp';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';

					$this->load->library('upload', $config);

					$errors = false;
					$result = true;


						if ($_FILES['mainImg']['tmp_name'] != "")
						{
							error_log($_FILES['mainImg']['tmp_name']);
							// If error occurs
						if (! $this->upload->do_upload('mainImg')){
							$this->session->set_flashdata('notice', $this->upload->display_errors());
							$errors = true;
							redirect(site_url() . '/pages/view/edit_cat/' . $cat_id);
							//redirect(site_url() . '/pages/view/add_cat/');
							}

						else{

							$mainImage = $this->upload->data();
							//$this->session->set_flashdata('notice', $this->upload->data('file_name'));
							// Resize the image
							// Delete the original

							}



						if($errors)
						// There was errors, we have to delete the uploaded files
						{

							@unlink($mainImage['full_path']);

						}

						else{

							//error_log(var_export($files, true));
							$this->load->library('image_lib');

							//Create folder
							//$dir_path = './inv_images/' . $invoice_id;

							// Check if directory exists
							//if(!is_dir($dir_path)){
							//	mkdir($dir_path, 0777);
							//}


							// Set up Image Manipulation
								$config_m['image_library'] = 'gd2';
								$config_m['maintain_ratio'] = TRUE;
								$config_m['width'] = 600;
								$config_m['source_image'] = $mainImage['full_path'];

								$this->image_lib->clear();
								$this->image_lib->initialize($config_m);
								$this->image_lib->resize();

								$image_filename = $mainImage['file_name'];
								$new_path = './' . 'cat_img/resized_cat_images_600/' . $image_filename;
								rename($mainImage['full_path'], $new_path);

								// Save thumbnail
								// Copy Image
								$new_path_300 = './cat_img/resized_cat_images_300/' . $image_filename;
								copy($new_path, $new_path_300);

								$this->image_lib->clear();
								$config_m['image_library'] = 'gd2';
								$config_m['maintain_ratio'] = TRUE;
								$config_m['width'] = 300;
								$config_m['source_image'] = $new_path_300;
								$this->image_lib->initialize($config_m);
								$this->image_lib->resize();

								//Save to database
								$img_array = array( 'image' => $image_filename );
								$this->load->model('catalogue_model');
								$result_image = $this->catalogue_model->update_image($cat_id, $img_array);

							}
						}

			// End Image Processing

			if ($cat_id && $result_array_cat_save && $result_image){
				$this->session->set_flashdata('notice', 'Cat Insert: ' . $cat_id .'<br />Attributes: ' . $result_array_cat_save . '<br />Image:' . $result_image);
			}
			else{
				$this->session->set_flashdata('notice', 'Cat Insert: ' . $cat_id .'<br />Attributes: ' . $result_array_cat_save . '<br />Image:' . $result_image);
			}
			redirect(site_url() . '/pages/view/edit_cat/' . $cat_id);
			//redirect(site_url() . '/pages/view/add_cat/');
		}


	}

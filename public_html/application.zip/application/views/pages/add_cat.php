<style type="text/css">
body {
	background-color: #000000;
}
	input{
		text-align: right;
	}
</style>

            <h2 class="page-title">Add New Cat<small></small></h2>

	<div class="row">
            <div class="col-md-12">
               <form class="form-horizontal form-label-left" method="post" action="<?php echo (site_url() . '/cats/save') ?>" enctype="multipart/form-data" data-parsley-validate="">
                <section class="widget">
                  <?php if ($this->session->flashdata('notice'))
						{
							echo('<span class="label label-important">' . $this->session->flashdata('notice'));
						} ?></span>
                    <header>
                        <h4><i class="fa fa-user"></i> Cat Image & Description <small></small></h4>
                        <div style="margin-top:20px;margin-bottom:30px"><img  style="width:100%" src=""/>
                        Cat Image: <input type="file" class="" name="mainImg" id="mainImg" /></div>
                        <h3 style="margin-bottom:15px">Name: <input type="text" name="cat_name" id="cat_name" value="" required></h3>
                        <h3 style="margin-bottom:15px">Sample #: <input type="text" name="cat_sample_no" id="cat_sample_no" value="" required></h3>
                        <h3 style="margin-bottom:15px">Override Price: $ <input type="text" name="cat_override" id="cat_override" value=""></h3><small>Note: A value set for Override Price will override any other price even after all calculations!</small>
												<h3 style="margin-bottom:15px;margin-top:15px">Category: </h3>
													<select class="xs-pull-right select2 form-control input-lg" data-placeholder="Select Cat Brand" tabindex="-1" id="category_id" name="category_id" required data-parsley-trigger="change" data-parsley-id="15">
													<option value></option>
													<?php foreach ($category_names as $category) : ?>
														<option value="<?php echo $category->category_id; ?>"><?php echo $category->name; ?></option>
													<?php endforeach; ?>
													</select>
												<fieldset>
                        <h4 style="margin-top:15px">Converter Description</h4>
                        <textarea id="desc" name="desc" style="width:100%;margin-top:20px; height:300px" required></textarea>
                        </fieldset>

                    <div class="specs">
                        <table>
						<tr><td colspan="2"><h4>Gross Weight Price&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h4></td><td colspan="2"></td>
						<th><input type="text" name="gross_weight_price" class="form-control" id="gross_weight_price" value="" required="required" data-parsley-trigger="change" data-parsley-id="20" /></th></tr>
						<tr><td colspan="2"><h4>Gross Weight Converter</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="gross_weight_converter" id="gross_weight_converter" value=""  required /></th></tr>
						<tr><td colspan="2"><h4>Gross Weight Monolith</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="gross_weight_monolith" id="gross_weight_monolith"  required value="" /></th></tr>
						<tr><td colspan="2"><h4>Monolith Dry Weight Moisture</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="monolight_dry_weight_moisture" id="monolight_dry_weight_moisture" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Monolith Dry Weight Metal</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="monolight_dry_weight_metal" id="monolight_dry_weight_metal" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Monolith Dry Weight Net</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="monolight_dry_weight_net" id="monolight_dry_weight_net" value="" required /></th></tr>
						<tr><td colspan="2"><h4>PD Analysis Accepted</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="analysis_accepted_pd" id="analysis_accepted_pd" value="" required /></th></tr>
						<tr><td colspan="2"><h4>PT Analysis Accepted</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="analysis_accepted_pt" id="analysis_accepted_pt" value="" required /></th></tr>
						<tr><td colspan="2"><h4>RH Analysis Accepted</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="analysis_accepted_rh" id="analysis_accepted_rh" value="" required /></th></tr>
						<tr><td colspan="2"><h4>PD Metal Content</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="metal_content_pd" id="metal_content_pd" value="" required /></th></tr>
						<tr><td colspan="2"><h4>PT Metal Content</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="metal_content_pt" id="metal_content_pt" value="" required /></th></tr>
						<tr><td colspan="2"><h4>RH Metal Content</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="metal_content_rh" id="metal_content_rh" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Value Returned Pd</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="value_returned_pd" id="value_returned_pd" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Value Returned Pt</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="value_returned_pt" id="value_returned_pt" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Value Returned Rh</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="value_returned_rh" id="value_returned_rh" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Value Returned Total</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="value_returned_total" id="value_returned_total" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Pd Refining Charges</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="refining_charges_pd" id="refining_charges_pd" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Pt Refining Charges</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="refining_charges_pt" id="refining_charges_pt" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Rh Refining Charges</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="refining_charges_rh" id="refining_charges_rh" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Sales Charges Pd</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="sales_charges_pd" id="sales_charges_pd" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Sales Charges Pt</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="sales_charges_pt" id="sales_charges_pt" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Sales Charges Rh</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="sales_charges_rh" id="sales_charges_rh" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Pd Metal Returned</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="metal_returned_pd" id="metal_returned_pd" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Pt Metal Returned</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="metal_returned_pt" id="metal_returned_pt" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Rh Metal Returned</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="metal_returned_rh" id="metal_returned_rh" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Process Charges TC</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="process_charges_tc" id="process_charges_tc" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Process Charges Decan</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="process_charges_decan" id="process_charges_decan" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Process Charges Comm</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="process_charges_comm" id="process_charges_comm" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Process Charges Lot</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="process_charges_lot" id="process_charges_lot" value="" required /></th></tr>
						<tr><td colspan="2"><h4>Converter</h4></td><td colspan="2"></td><th><input class="form-control" type="text" name="converter" id="converter" value="" required /></th></tr>
                        </table>
                    </div>
										<div class="form-actions">
                                <div class="row">
                                  <div class="col-sm-6 col-sm-offset-5">
                                        <button type="submit" class="btn btn-primary input-lg" >Save Cat</button>
                                        <!--<h4><strong>NOTE: You will need to recalculate prices on the calculator page after adding a cat to generate its price</strong></h4>-->
                                    </div>
                        </div>
                  </div>
                </section>

			</form>
            </div>
        </div>

        <script>
			var elem = document.querySelector('#isactive');
			var init = new Switchery(elem);
			$("#visit_frequency").val("<?php echo $customer->visit_frequency; ?>");
		</script>
       	</div>
</div>


    <!-- page specific scripts -->
        <!-- page libs -->

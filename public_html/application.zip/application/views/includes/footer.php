

<!-- common templates -->
<p class="text-align-center">&copy; Copyright 2017 All Rights Reserved. Cash 4 Cats</p>
	</body>
     
</html>